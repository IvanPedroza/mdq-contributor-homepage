# Preview 03 — annotation changes

Applied all 16 browser notes on 7 October 2026. Original notes remain in browser storage.

1. Removed “Your go-to people.”
2. Removed “The right files, in one place.”
3. Removed the Content WBS resource tile.
4. Removed the Microsoft Discovery Header resource tile.
5. Removed the QWC Recap Banner resource tile.
6. Removed the Publishing questions link above asset specifications.
7. Removed “Ready for the editor.”
8. Removed the asset section introductory paragraph.
9. Corrected maximum image width to **999 px**, per the user's annotation.
10. Removed “A clear path forward.”
11. Removed the Read the full guide link beside the process heading.
12. Replaced the process introduction's semicolon with a sentence break.
13. Removed owner summary sentences beneath Submit, Review and Publish. The expandable eleven-stage owner table is retained.
14. Removed “When you need a hand.”
15. Renamed the section “Frequently asked questions.”
16. Removed the Contact the team link beside the FAQ heading.

The full library remains available with all six source files. Three featured resource tiles remain: Publication guide, Tag taxonomy and Lessons learned. No SharePoint or GitHub changes.
