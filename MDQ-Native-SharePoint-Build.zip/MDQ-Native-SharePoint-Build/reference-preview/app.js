'use strict';
const trackerContent=document.querySelector('#tracker-content');
const recordButton='<button class="record-button" data-record>test</button>';
const stage='<span class="stage-label">Technical Review</span>';
function renderView(view){
 if(view==='list')trackerContent.innerHTML=`<div class="list-table-wrap"><table class="list-table"><thead><tr><th>Title</th><th>Status</th><th>Target date</th></tr></thead><tbody><tr><td class="article-cell">${recordButton}</td><td>${stage}</td><td class="date-cell">29 Oct</td></tr></tbody></table></div>`;
 else if(view==='board')trackerContent.innerHTML='<div class="board">'+['Submitted','Technical Review','Comms Review','Legal Review','Amplification Planning','Final Review','Published'].map(name=>`<section class="bucket"><h3>${name}</h3>${name==='Technical Review'?recordButton+'<small>Ivan Pedroza (Spur Reply LLC)<br>29 Oct 2026</small>':'<small>No items in this snapshot</small>'}</section>`).join('')+'</div>';
 else if(view==='calendar')trackerContent.innerHTML=`<p class="calendar-heading">October 2026 · saved publication target</p><div class="calendar-target"><span class="calendar-day">29</span><div>${recordButton}<p>Ivan Pedroza (Spur Reply LLC) · Technical Review</p></div></div><p class="list-note">Open the tracker for the full native calendar view.</p>`;
 else trackerContent.innerHTML='<p class="empty-view">The archive was not included in the saved page.<br>Open the tracker and select Your Archive to view its records.</p>';
}
renderView('list');
document.querySelector('#tracker-view').addEventListener('change',e=>renderView(e.target.value));
const dialog=document.querySelector('#record-dialog');let opener=null;
document.addEventListener('click',e=>{const button=e.target.closest('[data-record]');if(button){opener=button;dialog.showModal();}});
document.querySelector('#close-record').addEventListener('click',()=>dialog.close());
dialog.addEventListener('close',()=>opener?.focus());
document.querySelector('#show-parts').addEventListener('click',e=>{const shown=document.body.classList.toggle('show-parts');e.target.setAttribute('aria-pressed',String(shown));e.target.textContent=shown?'Hide web parts':'Show web parts';});
