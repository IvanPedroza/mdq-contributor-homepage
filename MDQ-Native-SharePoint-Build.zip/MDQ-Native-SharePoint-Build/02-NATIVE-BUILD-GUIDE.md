# Native SharePoint build guide — approved Preview 03

Use this with **03-PAGE-COPY-AND-LINKS.md** and the screenshots. The design is approved; do not introduce a new visual direction. Settings below are native options or clearly identified fallbacks, not custom CSS instructions.

## 1. Working context and page preparation

**Site:** https://microsoft.sharepoint.com/teams/MDQContentPublication

**Current homepage:** https://microsoft.sharepoint.com/teams/MDQContentPublication/SitePages/Contribute-to-Microsoft-Discovery.aspx

**Source List:** Blog Publication Tracker. **Source library:** Blog Program Resources.

1. Open the site with the work account that can edit this page. Use the normal SharePoint editor; do not use Graph writes in this tenant.
2. Open the existing homepage. Use **New → Copy of this page** if available. Otherwise use **New → Page** and choose a blank modern page, or create a modern page from Site Pages. Do not choose **HTML page**.
3. Name the draft **Contribute to Microsoft Discovery — redesign**. Save its URL for the final handoff. Keep the current homepage and `Home.aspx` unchanged.
4. Select **Edit**. Remove the redundant visible page-title/banner area on the new draft if present; retain the required page title in metadata. The animated banner will carry the brand. Provide a separate visible native heading for Start here.
5. Copying may retain old sections. Move/reuse their web parts where practical; remove redundant parts from the draft only as you replace them. Removing a List or library web part from a draft does not require deleting its underlying list/library.
6. Leave the SharePoint/Microsoft 365 header and site navigation as the site's own chrome. The prototype's imitation shell is not content to rebuild with Text or Image web parts.
7. Save as draft after each major section. If a page approval workflow applies, follow that workflow at release.

### Visual settings

- Body background: white. Keep content aligned to the standard page canvas.
- Main heading: Start here. Use the largest suitable native heading style. If Heading 1 is available, use it; otherwise use the native page/text heading hierarchy without injecting markup.
- Section headings: one consistent native heading style, visually below Start here. Use bold/semibold available through SharePoint, not imported fonts.
- Use the existing site's font. The prototype uses Segoe UI as a visual guide.
- Purple accent target: `#6641AC`; dark section target: `#171A32`; body text target: `#191625`. These are visual references, not guaranteed color inputs in every native property pane.
- Inspect **Settings → Change the look → Theme** for an existing approved purple theme, but keep that selection provisional while building the draft. Applying a theme affects the whole live site; apply the chosen existing theme only during the final release. If no suitable purple option exists, keep the current theme and record the difference. Do not create a tenant theme, install a theme extension or inject CSS as part of this build.
- Use section padding/spacing options exposed by the editor. Aim for generous section separation and consistent gaps; do not insert blank paragraphs to force alignment.
- Do not attempt edge-to-edge full-width sections on this team site. The approved layout fills the normal SharePoint page canvas.

## 2. Upload the artwork

1. Open **Site contents → Site Assets**. If Site Assets is not offered to this account, use an existing site library intended for page assets and accessible to the page's audience.
2. Create a folder named **Homepage Design** if it does not already exist.
3. Upload the three images from this package's `assets/` folder:
   - `publication-guide-art.png`
   - `asset-preparation-art.jpg`
   - `publication-path.jpg`
4. Keep their internal site permissions inherited. They do not need public sharing.
5. Select them later using the web part's **Change image / Select image → Site / Upload** picker. The tenant previously rejected external URLs in the Image web part, so do not use the GitHub image URL workaround.
6. See `assets/ASSET-USAGE.md` for placement and alt text. The supplied images contain no new heading text; native headings remain selectable and accessible.

## 3. Layout map

Build these actual sections in order. Native collapsible sections are separate sections, not nested HTML accordions.

| Order | Native section | Contents |
| --- | --- | --- |
| A | One column, white | Existing animated banner Embed |
| B | One-third right, white | Left: Start here, Hero with two tiles, captions. Right: proposal Text + Button, article-status Text + List and links |
| C | One-third left, dark | Left: program team. Right: three featured resource links |
| D | One column, white | Prepare your assets heading |
| E | Three columns, white | Images; Thumbnail & summary; Video |
| F | Three columns, white | Interactive content; Downloads; GIF |
| G | One column, white | From draft to published heading and approved introduction |
| H | Three columns, white | Submit; Review; Publish summaries |
| I | One column, collapsed | All 11 stages and their owners |
| J | One column, collapsed | View the complete process map |
| K | One column, collapsed | Browse all program documents and visual assets |
| L | One column, white | Frequently asked questions heading |
| M–R | Six one-column collapsed sections | One approved question and answer in each |
| Page setting | Comments enabled | Native comments, not a custom form |

For standard sections: hover the insertion point between sections → select the section **+** → choose the layout. Select the section's edit control to set background, spacing or collapsibility. Labels may vary with the tenant's current editor.

## 4. Section A — retain the animated banner

1. Reuse the existing **Embed** web part from the copied draft, or insert one in a normal one-column section.
2. Retain this exact host and `motion=on`:

```html
<iframe src="https://ivanpedroza.github.io/mdq-contributor-homepage/banner/index.html?motion=on" width="100%" height="312" title="MDQ Blog Program featured stories" style="border:0" loading="lazy"></iframe>
```

3. Set **Resize to fit the page** OFF if that option is present. Keep mobile display enabled.
4. The approved prototype proposes 312 px. Inspect a complete story-card cycle at desktop and narrow widths. If this clips the existing hosted banner, restore its current 398 px height and report the difference. Do not modify the hosted animation or shorten its internal content to force a fit.
5. This is the only Embed on the page. No full-page HTML iframe is part of the build.

## 5. Section B — start, submit and find your article

### B1. Wide left column

1. Add a **Text** web part. Enter the small label **For contributors**, then **Start here.** as a real heading. Use approved casing/heading punctuation from the copy file.
2. Add a small text link **Asset specifications**. Its destination will be the native link to the Prepare your assets heading, collected after that heading exists. Temporarily leave it unlinked rather than using a guessed `#assets` fragment.
3. Add a **Hero** web part beneath the heading. Open its properties → choose **Tiles** and use **Add a tile** or remove/reorder controls until exactly two tiles remain. If the editor instead offers a two-tile preset, choose that.
4. Configure the first tile:
   - Link: the publication-guide URL in the copy file.
   - Title: **The publication guide.**
   - Custom image: `publication-guide-art.png` from Site Assets.
   - Set a focal point/crop that retains the glass ribbon and dark area behind the title.
   - If a call-to-action option is available on that tile, enable **Open the guide**. Microsoft documents the extra CTA on the largest tile; the option may not appear in this exact two-tile arrangement. If absent, the linked title itself is the action. Do not draw a fake button into the image.
5. Configure the second tile:
   - Title: **Prepare your assets.**
   - Image: `asset-preparation-art.jpg`.
   - Destination: native link to the Prepare your assets heading, to be filled in later.
   - No extra CTA is needed.
6. Native Hero determines the tile proportions, title treatment and responsive behavior. Use the best native crop; do not promise the prototype's fixed 348 px geometry or custom gradient overlay.
7. Under Hero, add a compact **Text** web part with the two captions from the copy file. If they cannot line up below their respective tiles in the standard column, place them on two concise lines in tile order. Do not create a second nested column layout with HTML.

### B2. Right column — proposal

1. Add **Text** with **Have an idea?**, heading **Bring your story to life.**, and **Tell us the story you want to share.**
2. Add a **Button** web part directly below. Text: **Submit a blog proposal**. Link: the complete Microsoft Forms URL in the copy file. Left-align it; use the native filled theme style where available.
3. Use the native new-tab option if available and appropriate. Do not fabricate a custom arrow if the native control does not offer one.

### B3. Right column — live status

1. Add a **Text** heading **Article status** with a small **Full tracker** link pointing to the existing AllItems URL.
2. Add the native **List** web part. Select **Blog Publication Tracker** from this site.
3. In its property pane, select a compact saved view. Use All Items initially. For a cleaner homepage, create a separate public view named **Homepage summary** in the existing list:
   - Open the actual list → current view menu → **Create new view**, or **Save view as** if that is the available route.
   - Use List layout. Display **Title**, **Status**, and **Target Publication Date** in that order. Use the existing field names; do not add duplicate columns.
   - Sort by Target Publication Date ascending if that fits the team's current scheduling convention. Leave filtering unchanged unless an approved filter already exists; do not invent an Archived field or a My articles filter.
   - Do not make it the default view for the whole list and do not change the board's statuses.
   - Return to the page's List properties and select Homepage summary.
4. Choose a bounded/compact native size if available, then check several real rows. Show at least the title, status and target date without clipping the labels.
5. Prefer keeping native controls so the user can access available views. If the controls make the narrow column too busy, **Hide list controls** can hide the entire controls area; it does not leave a tiny custom view selector behind. Retain Full tracker and let readers switch views in the list itself. If using this fallback, adjust the status FAQ to say “Open Full tracker to switch between the All Items, Editorial Pipeline, Publication Calendar, and Your Archive views,” so it does not imply controls remain on the homepage.
6. Add **Find your article workspace** below, linked to the actual tracker. Workspace URLs remain in the existing records, not hand-maintained homepage cards.
7. Do not paste the prototype's `test` item, record count, saved date, calendar summary, snapshot note or record dialog into the page.
8. If the real List is too cramped in the right third, move the native List immediately below Section B into a white one-column section. Keep the proposal action and tracker/workspace links in the right column. This is the preferred native fallback; never replace live status with a static screenshot or fake HTML table. Record the layout difference for review.

## 6. Section C — team and resources

1. Add a **One-third left** section. Select a dark native background with readable light text, as close to the navy reference as the available theme allows.
2. Keep the section at normal canvas width. Do not place the List or Document Library in this dark section; those parts retain the page background.
3. Do not re-add the deleted labels **Your go-to people** or **The right files, in one place**.

### Left column: team

1. Add the heading **Your program team.** using **Text**.
2. Add **People**, choose **Small** layout and add these exact work identities: Katie Zoller, Ivan Pedroza and Anja Kurup, matched by their emails in the copy file.
3. Verify identity matches, especially contractor entries; use Microsoft 365 profile photos/presence rather than uploading the prototype's cached portraits.
4. Native People displays directory information. Do not try to rewrite someone's directory job title to match a program role.
5. Add compact **Text** immediately beneath People for the exact program contact details: name, clickable email and approved responsibility. Alternatively, use individual one-person People parts followed by each person's responsibility/email Text if the editor allows a clean compact stack.
6. Keep all three contacts visible, with their emails clearly readable. No standalone Contact the team link or extra support panel is needed.

### Right column: resources

1. Add heading **Guidance & templates.** and small **View library** text link to Blog Program Resources.
2. Add **Quick Links** and create exactly these three items, in this order:
   - Publication guide — Word
   - Tag taxonomy — Excel
   - Lessons learned — PowerPoint
3. Use their actual file URLs. Prefer **Button** layout with descriptions and the most suitable native appearance. Put the file type in the description or use the native file icon.
4. If **Tiles / Grid** gives a closer visual result, use it with native icons and titles; those layouts do not support descriptions. Do not assume labels can sit in the prototype's exact upper-left position.
5. Inspect the actual order. This tenant previously prepended added links, so either add them in reverse or use the native reorder control.
6. Enable new-tab behavior where available for the file links.
7. The removed **Content workback**, **Discovery header** and **QWC recap banner** tiles stay removed. Their files remain in the full library below; do not delete them from the library.

## 7. Sections D–F — asset preparation

1. Add a one-column **Text** heading: **Prepare your assets.** No eyebrow, introductory paragraph or Publishing questions link.
2. Add a three-column section below. Use one **Text** web part per column, with optional native Divider parts if useful:
   - Images: **999 px** / Maximum image width / PNG or JPG. Include alt text and a caption for every image.
   - Thumbnail & summary: **800 × 400** / Pixels, with a short summary / approved summary and header instructions.
   - Video: **1920 × 1080** / Final MP4 with captions / approved video instruction.
3. Use the dimension as the largest text in each column, a smaller category heading above it, then compact copy. Pick native text sizes; the CSS values in the prototype are not a configuration requirement.
4. Add another three-column section for **Interactive content**, **Downloads**, and **GIF**, with the exact short text from the copy file.
5. Keep both rows white with matching column alignment. Use a subtle native divider between the rows if available.
6. The maximum image width **999 px** is the user's approved correction. Do not restore the old handoff's 1000 px value. The public-release approval reminder still exists in the FAQ; the deleted asset introduction must remain deleted.

## 8. Sections G–J — publication path

1. Add a one-column Text section with heading **From draft to published.**
2. Paste the approved introduction as sentences, with no semicolon. Do not add **A clear path forward** or a Read the full guide link here.
3. Add a three-column section. Each Text web part contains the range, phase heading and summary from the copy file:
   - 01 — 02 / Submit.
   - 03 — 08 / Review.
   - 09 — 11 / Publish.
4. Do not add owner-caption sentences under these three summaries. They were explicitly removed.
5. Create a separate one-column section below. Edit its section properties:
   - Make this section collapsible: ON.
   - Show title: ON.
   - Title: **All 11 stages and their owners**.
   - Appropriate native heading level beneath the page sections; use the available closest level.
   - Divider: ON; expand/collapse icon on the right if offered.
   - Default display: Collapsed.
6. Add a **Text** web part with the eleven-row table in the copy file: Step / Stage / Owner. If the native Text editor cannot create this table, the native **Markdown** web part is an acceptable fallback for this table only. It must remain real text, not a screenshot.
7. Create another separate collapsed one-column section titled **View the complete process map** with the same title/divider/collapse treatment.
8. Add an **Image** web part and select the uploaded `publication-path.jpg`. Set the supplied alt text and caption. Use fit-to-width within its column; avoid cutting off any process boxes.
9. Keep the original eleven-stage sequence distinct from the List's seven board buckets. Do not rename tracker statuses to match the display.

## 9. Section K — full live resource library

1. Add a one-column white section and make it collapsible with the title **Browse all program documents and visual assets**, default Collapsed, divider ON.
2. Add **Document Library**. Select the existing **Blog Program Resources** library and its **All Documents** view.
3. Show **Name**, **Modified**, and **Modified By** through native view settings. If a separate homepage view is needed, create one without changing the default library view or deleting files.
4. Keep the library's live metadata, permissions and native opening behavior. Do not paste October snapshot dates or treat Modified By as a document owner field.
5. Include the **Open Blog Program Resources** link beneath the web part if it does not already provide an adequate full-library link.
6. All six supplied files must still be available here, including the three whose featured tiles were removed.

## 10. Sections L–R — frequently asked questions

1. Add the **Text** heading **Frequently asked questions.** No eyebrow and no Contact the team link.
2. Create six separate native one-column collapsible sections immediately below. Each section title is one exact question from the copy file; its body is a Text web part containing that answer.
3. Set default display to Collapsed, show the title and divider, and align the expand/collapse icon right if available.
4. Make every named Form/contact link an actual hyperlink or mailto link. Preserve the revised upload-error answer with direct Ivan/Anja links; do not restore the stale Get help reference.
5. Keep the visible questions legible and consistent. Do not rely on a custom FAQ app, JavaScript accordion or HTML details element.
6. Retain the FAQ instruction to request the Tech Community author profile from Katie promptly after acceptance.

## 11. Native heading links, comments and page settings

1. Save the draft, leave edit mode and locate **Prepare your assets.** Hover its native heading and use the displayed heading-link control / Copy link if supported. Copy the actual SharePoint-generated address.
2. Edit again and use that address for **Asset specifications** and the **Prepare your assets.** Hero tile.
3. Do not copy the prototype's localhost URL, `#assets` or other manually assigned HTML IDs. If the tenant does not expose heading links for this native heading, use a supported page-section navigation control if available. Otherwise use the actual publication guide URL as a temporary resource destination and explicitly report the difference; do not leave a broken link or claim an anchor was configured.
4. Leave native page comments ON. The prototype's **Keep the conversation going / Open page comments** row represents that native area; do not add a duplicate comments widget or a self-link.
5. Turn off the **You may also be interested in** recommended-content strip if the setting is present, so unrelated tenant content is not appended.
6. Keep existing permissions and the underlying Form/List/library/flows unchanged.
7. Save the draft and follow the validation checklist before release.

## 12. Copilot section prompts

These prompts are optional aids for the native editor. Use **Add a section with AI/Copilot** if available. Inspect the result and continue with the manual steps above. A result made of HTML in an iframe is not acceptable for the body.

**Asset text sections**

> Add native Text web parts for the approved asset specifications. Use three equal columns for Images, Thumbnail & summary and Video, followed by three equal columns for Interactive content, Downloads and GIF. Use the exact copy I provide next. Make dimensions visually prominent, retain the white background, and do not add introductions, icons, buttons, images or new guidance. Maximum image width is 999 px.

**Process overview**

> Add a native three-column Text section with the supplied ranges and phase summaries: 01 — 02 Submit, 03 — 08 Review, 09 — 11 Publish. Use only the exact supplied text. Do not add owner captions or invent tracker stages. Keep the white background and clear heading hierarchy.

**FAQ sections**

> Create six separate native collapsible one-column sections beneath Frequently asked questions. Use each supplied question as its section title and the corresponding answer in a Text web part. Default to collapsed. Show dividers and use right-aligned collapse icons if available. Preserve the exact links, and add no preface or contact link beside the main heading.

Use ordinary editor controls for the Hero, List, Document Library, People and Quick Links configuration. **Design Ideas** supports only certain section compositions and does not generally apply to sections containing Quick Links or People. It must not be treated as a universal restyling engine.

## 13. Native limitations to report, not conceal

- The standard team-site page canvas has margins. Neither the body nor the existing Embed is a full-width custom canvas.
- Hero chooses its own tile geometry. CTA availability depends on tile/layout, and native wrapping may differ.
- Quick Links layout controls descriptions, icon placement and spacing; it cannot reproduce arbitrary CSS cards.
- People pulls directory details. Exact program-role captions and emails may need adjacent Text.
- Hiding List controls hides all controls. The tiny prototype dropdown is not a custom control to recreate.
- No custom code connects this prototype to live data. The actual native List and library provide that functionality.
- Copilot permissions, availability and actions vary. If an interface only produces suggestions, describe that honestly and use the editor manually.

## Microsoft documentation checked for this handoff

- [Hero](https://support.microsoft.com/en-us/sharepoint/pages-in-sharepoint/use-the-hero-web-part)
- [Sections, backgrounds and collapse settings](https://support.microsoft.com/en-us/sharepoint/pages-in-sharepoint/add-sections-and-columns-on-a-sharepoint-modern-page)
- [List web part](https://support.microsoft.com/en-us/sharepoint/lists/web-parts-and-apps-in-sharepoint/use-the-list-web-part)
- [Quick Links](https://support.microsoft.com/en-us/sharepoint/sites-pages/use-the-quick-links-web-part)
- [Document Library](https://support.microsoft.com/en-au/sharepoint/web-parts-and-apps-in-sharepoint/use-the-document-library-web-part)
- [Section Design Ideas](https://support.microsoft.com/en-us/sharepoint/sites-pages/section-design-ideas)
- [Create a section with Copilot](https://support.microsoft.com/en-us/sharepoint/copilot-in-sharepoint/create-section-with-copilot)
- [Create pages with AI](https://support.microsoft.com/en-us/sharepoint/sites-pages/create-pages-with-ai-in-sharepoint)
- [Separate HTML-page workflow — excluded from this build](https://support.microsoft.com/en-us/sharepoint/create-edit-publish-html-pages)
