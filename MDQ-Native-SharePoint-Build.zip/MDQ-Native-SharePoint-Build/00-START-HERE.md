# MDQ native SharePoint homepage — approved build package

Approved design: **Preview 03**, including all 16 annotation changes. Prepared 7 October 2026.

This package is the design and construction brief for a **modern SharePoint page built with native web parts**. It is not a deployable app package. The existing animated banner remains the only Embed.

## Use on your work computer

1. Extract this ZIP into a folder on your work computer.
2. Open the approved reference in `screenshots/approved-desktop.jpg`. For an interactive reference, open `reference-preview/index.html` in a browser. The prototype can display its saved record offline; work links and live hosted content require the appropriate connection and sign-in.
3. In your work Copilot chat, attach **02-NATIVE-BUILD-GUIDE.md**, **03-PAGE-COPY-AND-LINKS.md**, and **screenshots/approved-desktop.jpg**. If that interface cannot read Markdown attachments, paste their text instead. If it only accepts images, use the screenshot and paste the instructions in chunks.
4. Copy all of **01-COPILOT-PROMPT.txt** into the chat. The prompt asks for a saved draft with native parts. It does not assume Copilot has browser-control or publishing permissions.
5. Use Copilot in the SharePoint editor to help create individual text/image sections where available. Follow the guide's manual steps to bind the existing List, library, people and links. A chat that only generates text cannot click these controls for you.
6. Upload only the three images in `assets/` to the site's **Site Assets / Homepage Design** folder. The rest of this ZIP is reference material, not homepage web-part content.
7. Review the draft using **04-VALIDATION-AND-RELEASE.md**, then publish when ready.

## What is included

| File / folder | Purpose |
| --- | --- |
| 01-COPILOT-PROMPT.txt | Ready-to-paste master instruction |
| 02-NATIVE-BUILD-GUIDE.md | Ordered editor steps, section layout, web-part settings, Copilot prompts and fallbacks |
| 03-PAGE-COPY-AND-LINKS.md | Approved copy, full destinations, people, specifications, FAQ and ownership table |
| 04-VALIDATION-AND-RELEASE.md | Acceptance checks, publishing steps and recovery |
| 05-APPROVED-CHANGES.md | The 16 changes already approved; do not restore removed content |
| assets/ | Three images ready to upload, plus usage notes |
| screenshots/ | Desktop and narrow-screen references of the approved composition |
| reference-preview/ | Local visual prototype, not code to insert into SharePoint |
| content-manifest.json | Structured source references and approved values |
| SHA256SUMS.txt | File checksums for the packaged files |

## Important distinctions

- Choose **Page / modern ASPX page**, not **HTML page**. Do not upload the prototype as the SharePoint homepage.
- The body uses Hero, Text, Button, People, Quick Links, List, Document Library, Image and native collapsible sections. No SPFx, ShortPoint, Script Editor, custom page CSS or body iframe is required.
- Copilot generation is assistance, not a guarantee of exact placement or live data connections. The manual editor steps are the implementation path when a generated section is unsuitable.
- Native controls and tile proportions will differ somewhat from the reference. Keep the approved content, ordering and hierarchy rather than chasing arbitrary CSS measurements.
- The prototype's `test` record and saved document dates are a snapshot. The real page must read the existing List and library; never create those sample values.
- This handoff contains internal program references and is intended for the work environment. It has not been pushed to a public repository.

The existing live home page is:
https://microsoft.sharepoint.com/teams/MDQContentPublication/SitePages/Contribute-to-Microsoft-Discovery.aspx
