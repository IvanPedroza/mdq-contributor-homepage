# Approved page copy and links

Content inventory for approved preview 03, dated 7 October 2026. The approved `index.html` controls visible copy; `content.json` supplies source links and metadata. The user's **999 px** correction supersedes the original 1000 px specification. Line breaks in headings are visual choices; the wording below is unchanged.

This file contains page content and source facts, not editor instructions. Review controls, annotations, snapshot notes, sample tracker records and the local record dialog are not production page copy.

## 1. Site, navigation and existing banner

Site name: **MDQ Content Publication**

Site: [MDQ Content Publication](https://microsoft.sharepoint.com/teams/MDQContentPublication)

Current homepage: [Contribute to Microsoft Discovery](https://microsoft.sharepoint.com/teams/MDQContentPublication/SitePages/Contribute-to-Microsoft-Discovery.aspx)

| Navigation label | Destination |
| --- | --- |
| Home | [Site home](https://microsoft.sharepoint.com/teams/MDQContentPublication) |
| Article tracker | [Blog Publication Tracker](https://microsoft.sharepoint.com/teams/MDQContentPublication/Lists/Blog%20Publication%20Tracker/AllItems.aspx) |
| Blog assets | [Blog Assets](https://microsoft.sharepoint.com/teams/MDQContentPublication/Blog%20Assets/Forms/AllItems.aspx) |
| Program resources | [Blog Program Resources](https://microsoft.sharepoint.com/teams/MDQContentPublication/Blog%20Program%20Resources/Forms/AllItems.aspx) |

The existing animated banner remains the only Embed. Its current hosted URL is [MDQ Blog Program banner](https://ivanpedroza.github.io/mdq-contributor-homepage/banner/index.html?motion=on). Preserve the banner's existing content and story links; do not turn the local page body into an Embed.

Approved iframe title: **MDQ Blog Program featured stories**

## 2. Start here and editorial tiles

Small heading: **For contributors**

Main heading: **Start here.**

Link label: **Asset specifications**

Internal destination: the actual SharePoint-generated heading link for **Prepare your assets.** on the finished page. That URL does not exist in the local preview. The same destination is used for the second tile; do not copy the prototype's `#assets` fragment or a localhost address.

### Publication guide tile

Title: **The publication guide.**

CTA label: **Open the guide**

Caption: Your companion from submission to launch.

Destination: [Microsoft Discovery Blog Publication Guide](https://microsoft.sharepoint.com/teams/MDQContentPublication/Blog%20Program%20Resources/Microsoft%20Discovery%20Blog%20Publication%20Guide.docx?web=1)

Packaged upload image: `assets/publication-guide-art.png` — the abstract artwork generated in one pass for the approved preview. Decorative image; the tile title supplies the link's meaning.

### Asset preparation tile

Title: **Prepare your assets.**

Caption: Specifications, hosting, and public access.

Destination: the actual SharePoint-generated heading link for **Prepare your assets.** described above. This tile has no separate CTA label.

Packaged upload image: `assets/asset-preparation-art.jpg` — rendered from the approved glass artwork/background so no custom CSS is required. Decorative image; the tile title supplies the link's meaning.

## 3. Proposal submission

Small heading: **Have an idea?**

Heading: **Bring your story to life.**

Body: Tell us the story you want to share.

Button: [Submit a blog proposal](https://forms.cloud.microsoft/Pages/ResponsePage.aspx?id=v4j5cvGGr0GRqy180BHbR__QMmLK2ntOv7m47E7ymNJUME1YTzhSVjZTNENGVjY1UlFVUU9ZWlhZNCQlQCN0PWcu)

## 4. Article status

Heading: **Article status**

Links: [Full tracker](https://microsoft.sharepoint.com/teams/MDQContentPublication/Lists/Blog%20Publication%20Tracker/AllItems.aspx) · [Find your article workspace](https://microsoft.sharepoint.com/teams/MDQContentPublication/Lists/Blog%20Publication%20Tracker/AllItems.aspx)

Live source: **Blog Publication Tracker** on this site. Homepage column labels in the preview are **Title**, **Status**, **Target date**; the underlying date field is Target Publication Date.

Existing view labels: **All Items**, **Editorial Pipeline**, **Publication Calendar**, **Your Archive**. Known direct URLs are [All Items](https://microsoft.sharepoint.com/teams/MDQContentPublication/Lists/Blog%20Publication%20Tracker/AllItems.aspx) and [Editorial Pipeline](https://microsoft.sharepoint.com/teams/MDQContentPublication/Lists/Blog%20Publication%20Tracker/EditorialPipeline.aspx). Direct URLs for the other two views were not captured; do not invent them.

Existing source statuses: Submitted; Technical Review; Comms Review; Legal Review; Amplification Planning; Final Review; Published. These are distinct from the eleven publication stages below. Records and counts must come from the live List, not the saved test record.

## 5. Program team

Heading: **Your program team.**

| Display name | Visible email and mail link | Program responsibility |
| --- | --- | --- |
| Katie Zoller | [Katie.Zoller@microsoft.com](mailto:Katie.Zoller@microsoft.com) | Editorial & author access |
| Ivan Pedroza | [v-ipedroza@microsoft.com](mailto:v-ipedroza@microsoft.com) | Publication Operations |
| Anja Kurup | [v-ankurup@microsoft.com](mailto:v-ankurup@microsoft.com) | Publication Operations |

These approved responsibility labels are program copy, not replacements for Microsoft 365 profile job titles. Native profile names, photos and presence remain live directory information.

## 6. Featured guidance and templates

Heading: **Guidance & templates.**

Link: [View library](https://microsoft.sharepoint.com/teams/MDQContentPublication/Blog%20Program%20Resources/Forms/AllItems.aspx)

Only these three featured links remain in the approved resource band:

| Label | File-type label | Full destination |
| --- | --- | --- |
| Publication guide | Word | [Microsoft Discovery Blog Publication Guide.docx](https://microsoft.sharepoint.com/teams/MDQContentPublication/Blog%20Program%20Resources/Microsoft%20Discovery%20Blog%20Publication%20Guide.docx?web=1) |
| Tag taxonomy | Excel | [Microsoft Discovery Tag Taxonomy.xlsx](https://microsoft.sharepoint.com/teams/MDQContentPublication/Blog%20Program%20Resources/Microsoft%20Discovery%20Tag%20Taxonomy.xlsx?web=1) |
| Lessons learned | PowerPoint | [Microsoft Discovery Blog Lessons Learned.pptx](https://microsoft.sharepoint.com/teams/MDQContentPublication/Blog%20Program%20Resources/Microsoft%20Discovery%20Blog%20Lessons%20Learned.pptx?web=1) |

## 7. Prepare your assets

Heading: **Prepare your assets.**

There is no introductory paragraph or Publishing questions link in this section.

### Images

**999 px**

**Maximum image width**

PNG or JPG. Include alt text and a caption for every image.

### Thumbnail & summary

**800 × 400**

**Pixels, with a short summary**

Summary: 140 characters or less. Optional header: 1300 × 500 px, no GIF.

### Video

**1920 × 1080**

**Final MP4 with captions**

Prepare the final video before it goes into the Tech Community editor.

### Interactive content

Requires a hosting review and a static fallback image.

### Downloads

Must be hosted at a public destination before publication.

### GIF

Keep the final file at 9.8 MB or smaller.

## 8. Publication overview

Heading: **From draft to published.**

Every article moves through the same eleven stages. The tracker shows your current stage. The owner listed here moves it forward.

**01 — 02 · Submit.**

Blog content submission form  
Draft submission

**03 — 08 · Review.**

Content, SEO, technical, comms, legal, and final content review.

**09 — 11 · Publish.**

Amplification plan, staging, and publication.

There are no owner sentences under these three summaries and no Read the full guide link beside the process heading.

## 9. Full stage and owner reference

Collapsible title: **All 11 stages and their owners**

| Step | Stage | Owner |
| --- | --- | --- |
| 01 | Blog content submission form | Author |
| 02 | Draft submission | Author, with automated intake |
| 03 | First content review | Katie Zoller |
| 04 | SEO review | Ivan Pedroza and Anja Kurup |
| 05 | Technical review | Assigned technical reviewers |
| 06 | Comms review | MDQ PR lead |
| 07 | Legal review | Discovery CELA, via Operations |
| 08 | Final content review | Katie Zoller |
| 09 | Amplification plan | Editorial, August Laguio, PR |
| 10 | Staging in the Tech Community editor | Main author with Operations |
| 11 | Publication | Katie Zoller |

## 10. Original process map

Collapsible title: **View the complete process map**

Source image in approved preview: `assets/publication-path.jpg`.

Caption: The program’s publication path and automated intake steps.

Alt text: Blog Publication Path: form, draft, first content review, SEO, technical, comms, legal, final content review, amplification, staging, publication. Automated intake creates a folder, tracker entry, email and Teams chat.

## 11. Complete program library

Collapsible title: **Browse all program documents and visual assets**

Live source: **Blog Program Resources**, view **All Documents**. Visible columns in the preview: **Name**, **Modified**, **Modified by**. Modified dates and people must remain live library values rather than pasted snapshot data.

| Exact file name | Full destination |
| --- | --- |
| Content WBS.xlsx | [Open file](https://microsoft.sharepoint.com/teams/MDQContentPublication/Blog%20Program%20Resources/Content%20WBS.xlsx?web=1) |
| Microsoft Discovery Blog Lessons Learned.pptx | [Open file](https://microsoft.sharepoint.com/teams/MDQContentPublication/Blog%20Program%20Resources/Microsoft%20Discovery%20Blog%20Lessons%20Learned.pptx?web=1) |
| Microsoft Discovery Blog Publication Guide.docx | [Open file](https://microsoft.sharepoint.com/teams/MDQContentPublication/Blog%20Program%20Resources/Microsoft%20Discovery%20Blog%20Publication%20Guide.docx?web=1) |
| Microsoft Discovery Tag Taxonomy.xlsx | [Open file](https://microsoft.sharepoint.com/teams/MDQContentPublication/Blog%20Program%20Resources/Microsoft%20Discovery%20Tag%20Taxonomy.xlsx?web=1) |
| Microsoft_Discovery_Header.jpg | [Open file](https://microsoft.sharepoint.com/teams/MDQContentPublication/Blog%20Program%20Resources/Microsoft_Discovery_Header.jpg?web=1) |
| QWC Recap Banner.png | [Open file](https://microsoft.sharepoint.com/teams/MDQContentPublication/Blog%20Program%20Resources/QWC%20Recap%20Banner.png?web=1) |

Link below the library: [Open Blog Program Resources](https://microsoft.sharepoint.com/teams/MDQContentPublication/Blog%20Program%20Resources/Forms/AllItems.aspx)

All six files remain in the library inventory. Removing three featured tiles did not remove their files or library links.

## 12. Frequently asked questions

Heading: **Frequently asked questions.**

### How do I get started?

Submit the [blog proposal form](https://forms.cloud.microsoft/Pages/ResponsePage.aspx?id=v4j5cvGGr0GRqy180BHbR__QMmLK2ntOv7m47E7ymNJUME1YTzhSVjZTNENGVjY1UlFVUU9ZWlhZNCQlQCN0PWcu). Operations creates your tracker item, and you will hear back about next steps.

### Where can I see the status of my article?

In the Blog Publication Tracker on this page. Switch between the All Items, Editorial Pipeline, Publication Calendar, and Your Archive views.

### Who reviews my draft, and in what order?

Follow the Blog Publication Path: first content review, SEO review, technical review, comms review, legal review, and a final content review before amplification, staging, and publication.

### What image, video, and GIF specs do I need to meet?

See Prepare your assets above. Every asset also needs public-release approval before staging.

### The Tech Community editor is not accepting my upload or link. What now?

Contact Publication Operations: [Ivan Pedroza](mailto:v-ipedroza@microsoft.com) or [Anja Kurup](mailto:v-ankurup@microsoft.com). Include the article title and tracker link, current stage, workspace or asset link, error message or screenshot, and target publication date.

### How do I get a Tech Community author profile?

Contact [Katie Zoller](mailto:Katie.Zoller@microsoft.com). Request it as soon as your proposal is accepted so staging is not delayed.

## 13. Comments and page-level content

Prototype footer text: **Keep the conversation going.** This represents the native comments area; it is not a required extra footer web part.

Preview-only link label: **Open page comments**. Do not copy this self-link into the new page. The finished native page uses its own native comments, not the local preview or a simulated submission form.

Comments: **enabled**. Unrelated recommended-content strip: **off** in the approved design. No Contact the team link or additional eyebrow appears beside the FAQ heading.
