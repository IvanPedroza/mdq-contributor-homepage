# Validate the native draft, then release

Use this checklist on the actual SharePoint draft. The local reference prototype is not evidence that the SharePoint build or its permissions have been tested.

## 1. Content and layout acceptance

- [ ] The body is native SharePoint. Only the existing animated banner is embedded. No HTML-page body, custom CSS, SPFx or ShortPoint dependency was introduced.
- [ ] The page metadata title remains meaningful; Start here is visible as a real heading.
- [ ] Both visual Hero tiles use the uploaded artwork and descriptive linked titles.
- [ ] Submit a blog proposal, the guide, article status/workspace access and contacts are easy to find near the top.
- [ ] The three featured resource links are Publication guide, Tag taxonomy and Lessons learned, in that order.
- [ ] Content workback, Discovery header and QWC recap banner are absent from the featured tiles but remain available in the full library.
- [ ] All three people have the correct names, emails and program responsibilities. Directory identities were matched by email.
- [ ] Asset instructions show **999 px**, **800 × 400**, **140 characters or less**, **1300 × 500**, **1920 × 1080**, and **9.8 MB or smaller**, as approved.
- [ ] The asset introduction, Ready for the editor label and Publishing questions link remain removed.
- [ ] Submit / Review / Publish has the correct stage ranges and no owner captions beneath its three summaries.
- [ ] The process introduction has no semicolon. All eleven owners remain in the expandable detail table.
- [ ] The process map fits its column with every box visible and has meaningful alt text.
- [ ] The heading is Frequently asked questions. Six questions remain, collapsed by default, with the corrected direct-contact answer.
- [ ] All other removed labels and links listed in 05-APPROVED-CHANGES.md remain removed.
- [ ] Native comments are enabled. The prototype comments self-link, mock Microsoft 365 shell, Show web parts button, annotation toolbar and saved-data notes were not copied into the page.
- [ ] Unrelated recommended content is off if that setting is available.

## 2. Verify real data and destinations

1. Open the List web part's property pane and confirm its selected source is the existing **Blog Publication Tracker** on **MDQContentPublication**, not a copied list. Record the selected view.
2. Compare a few visible records with the actual list, including title, status and target date. Do not create a dummy item merely to test the layout, and do not infer the total article count from the prototype's single saved item.
3. Open Full tracker and verify the existing All Items, Editorial Pipeline, Publication Calendar and Your Archive views are reachable there. If the homepage hides list controls, verify the Full tracker link is still prominent.
4. Open Find your article workspace. Verify it reaches the tracker. Check an existing record with a real workspace link if one is available; a blank link in the saved test record is not a homepage rendering failure.
5. Confirm the Document Library web part selects **Blog Program Resources**. Compare its Modified and Modified By values with the live library; do not use the local snapshot dates.
6. Open each of the three featured documents and confirm it is the intended file. Confirm all six source files are still available in the full library.
7. Open the submission Form and confirm it is the real existing form. Do not submit an unrequested test response.
8. Click Asset specifications and the Prepare your assets tile. They should land on the actual native heading/section. Confirm no localhost or guessed fragment URLs remain.
9. Inspect the three mailto links and all FAQ links for exact destinations.
10. Open an existing published story from the banner. Confirm the story link works and the banner is moving during a full card cycle.

## 3. Browser, access and accessibility checks

- [ ] Inspect the page at a normal desktop width and a narrow/mobile width. Native columns should stack without clipped headings, buttons or horizontal page overflow.
- [ ] If 312 px clips the hosted banner, restore its prior 398 px frame height and record that native compromise. Do not ship clipped story text.
- [ ] The native List is readable in its column. If not, apply the documented full-width-within-canvas white-section fallback below the entry area.
- [ ] All dark-section text and links are readable. Use native theme alternatives if the exact reference navy is unavailable.
- [ ] Tab through buttons, tiles, links and collapse controls. Check visible focus and Enter/Space behavior supplied by the native parts.
- [ ] Confirm heading hierarchy in the editor and use real headings, not bold-only labels, for navigation targets.
- [ ] Confirm decorative art is treated appropriately and process-map alt text is present. Keep functional link titles visible rather than baking them into artwork.
- [ ] Review with a typical existing site member account when available. Verify that pages, documents and Site Assets open under the current permissions; do not expand access just to make a test pass.
- [ ] Save, leave edit mode and inspect the saved draft again. Editor previews alone are insufficient.

## 4. Draft handoff report

Have Copilot or the builder return this concise record:

- Draft page URL:
- Native page type confirmed:
- List source and saved view:
- Library source and saved view:
- Uploaded image folder:
- Working native asset-section link:
- Banner height used:
- Layout differences from the approved mockup:
- Checks completed and anything still unverified:

The target is a usable native interpretation, not a claim of pixel-identical HTML rendering.

## 5. Publish when the draft is ready

This package itself does not publish anything. After reviewing the actual draft:

1. If a site-theme change is part of the accepted release, apply the selected existing theme through Settings → Change the look → Theme. Remember this affects other site pages, so inspect those shared header/button colors as well. Otherwise keep the current site theme.
2. Open the new draft and select **Publish** or follow the site's approval/submission action if approval is enabled.
3. View the published page, recheck the important links and verify the List/library are live.
4. Open **Site contents → Site Pages**. Find the newly published page, select its **…** menu and choose **Make homepage** if that option is available to the page/site owner.
5. Open the site root and confirm it now loads the new page.
6. Retain both the former modern homepage and `Home.aspx`. Do not delete them as part of this release.
7. If you later update native heading links because the page URL changed, edit, save and republish those links. Do not rename the page after final link verification without rechecking them.

## 6. Recovery

If the new homepage has a material issue, use Site Pages → the prior **Contribute-to-Microsoft-Discovery.aspx** → **… → Make homepage** to restore the previous entry point. Correct the new page as a draft. The underlying list, library, documents, form and flows should not need restoring because this build does not replace them.

If someone edited the existing page rather than a separate draft, use that page's version history and normal SharePoint restore/publish workflow. Record which version was restored.
