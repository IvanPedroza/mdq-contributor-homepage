# Images to upload to SharePoint

Upload these three images into **Site Assets / Homepage Design** using the work account. Choose them through native image pickers. Do not upload the local prototype as the homepage.

| File | Use | Accessibility and crop |
| --- | --- | --- |
| publication-guide-art.png | Publication-guide Hero tile | Decorative abstract glass ribbon. Keep the functional native title “The publication guide.” visible; use decorative alt treatment where offered, or concise “Purple glass ribbon” if the field requires text. Use focal point/crop controls to retain the ribbon. |
| asset-preparation-art.jpg | Prepare-your-assets Hero tile | Approved purple disc with the background already rendered into the image. No CSS filter/transform or transparent-layer placement is needed in SharePoint. Use decorative alt treatment where offered, or “Purple glass disc.” Native title: “Prepare your assets.” |
| publication-path.jpg | Image inside the collapsed process-map section | Do not crop the diagram. Alt: “Blog Publication Path: form, draft, first content review, SEO, technical, comms, legal, final content review, amplification, staging, publication. Automated intake creates a folder, tracker entry, email and Teams chat.” Caption: “The program’s publication path and automated intake steps.” |

The glass ribbon is the artwork generated for the approved design. The purple-disc JPEG is a browser-rendered export of the existing approved tile's artwork/background with the text removed from the export surface; it adds no new visual concept. The process map is the original supplied program diagram.

Native Hero may apply its own overlay and crop. Adjust native settings for contrast; do not recreate HTML image transforms, and do not bake titles into the image to compensate.

Profile pictures come from the native People web part. The reference preview's cached photo and logo are visual-reference assets, not additional uploads required for the page body.
